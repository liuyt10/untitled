# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : run.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-07-31 11:33
# @Copyright: 北京码同学

import os
import sys

import pytest

from common.file_load import load_yaml_file, write_yaml

if __name__ == '__main__':
    # 解析终端执行时，传入的环境名称，根据环境名称去修改各项配置文件
    args = sys.argv
    print(args)
    env_file_path = f'/config/env_test.yml'
    if len(args)>1:
        env_name = args[1] # 得到传进来的环境名称
        env_file_path = f'/config/env_{env_name}.yml'
        # 环境配置文件路径生成后，将传进来的环境名称删除掉，否则会被当做pytest要执行的测试用例
        del args[1]
    # 读取对应的环境配置信息
    env_info = load_yaml_file(env_file_path)
    # 将环境信息分别写入到common.yml、http.yml、db.yml、redis.yml中
    write_yaml('/config/common.yml',env_info['common'])
    write_yaml('/config/http.yml', env_info['http'])
    write_yaml('/config/db.yml', env_info['db'])
    write_yaml('/config/redis.yml', env_info['redis'])
    # 会自动扫描当前目录下的pytest.ini
    # 根据配置文件中的配置来执行测试
    pytest.main()
    # 执行命令，生成测试报告
    os.system('allure generate ./report/data -o ./report/html --clean')
