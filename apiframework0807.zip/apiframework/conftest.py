# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : conftest.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-07-31 11:33
# @Copyright: 北京码同学
from typing import List

import pytest

from api.base_api import BaseBuyerApi, BaseSellerApi, BaseManagerApi
from api.buyer.buyer_login_apis import BuyerLoginApi
from api.buyer.checkout_params_apis import SetAddressIdApi
from api.buyer.member_address_apis import AddAddressApi, DeleteAddressApi
from api.manager.goods_apis import BatchAuditGoodsApi
from api.manager.manager_login_apis import ManagerLoginApi
from api.seller.goods_apis import AddGoodsApi, GetSkuInfoGoodsApi, UnderGoodsApi, RecycleGoodsApi, DeleteGoodsApi
from api.seller.seller_login_apis import SellerLoginApi
from common.db_util import DBUtil
from common.file_load import load_yaml_file
from common.json_util import extract_json
from common.redis_util import RedisUtil


def pytest_collection_modifyitems(
        session: "Session", config: "Config", items: List["Item"]
) -> None:
    # item表示每个测试用例，解决用例名称中文显示问题
    for item in items:
        item.name = item.name.encode("utf-8").decode("unicode-escape")
        item._nodeid = item._nodeid.encode("utf-8").decode("unicode-escape")

# 自定义一个fixture，来实现买家token的提取和赋值
@pytest.fixture(scope='session',autouse=True)
def get_buyer_token():
    common_info = load_yaml_file('/config/common.yml')
    buyer_login_api = BuyerLoginApi(username=common_info['buyerName'],password=common_info['buyerPassword'])
    resp = buyer_login_api.send()
    # BaseBuyerApi.buyer_token = resp.json()['access_token']
    BaseBuyerApi.buyer_token = extract_json(resp.json(),'$..access_token')
    BaseBuyerApi.uid = resp.json()['uid']
@pytest.fixture(scope='session',autouse=True)
def get_seller_token():
    common_info = load_yaml_file('/config/common.yml')
    seller_login_api = SellerLoginApi(username=common_info['sellerName'],password=common_info['sellerPassword'])
    resp = seller_login_api.send()
    print(resp.text)
    BaseSellerApi.seller_token = resp.json()['access_token']
@pytest.fixture(scope='session',autouse=True)
def get_manager_token():
    common_info = load_yaml_file('/config/common.yml')
    manager_login_api = ManagerLoginApi(username=common_info['managerName'],password=common_info['managerPassword'])
    resp = manager_login_api.send()
    BaseManagerApi.manager_token = resp.json()['access_token']

@pytest.fixture(scope='session',autouse=True)
def redis_util():
    redis_info = load_yaml_file('/config/redis.yml')['mtxshop']
    redis_util = RedisUtil(host=redis_info['host'], pwd=redis_info['password'])
    yield redis_util

@pytest.fixture(scope='session',autouse=True)
def db_util():
    db_info = load_yaml_file('/config/db.yml')['mtxshop']
    db_util = DBUtil(host=db_info['host'],user=db_info['username'],password=db_info['password'])
    yield db_util
    db_util.close()

@pytest.fixture(scope='class')
def goods_data():
    # 发布商品
    add_goods_api = AddGoodsApi()
    resp = add_goods_api.send()
    # 获取商品id
    goods_id = resp.json()['goods_id']
    # 管理员审核商品
    BatchAuditGoodsApi(goods_ids=[goods_id]).send()
    # 审核完成以后，获取商品的sku信息
    resp = GetSkuInfoGoodsApi(goods_id).send()
    # sku_id = resp.json()[0]['sku_id']
    sku_id = extract_json(resp.json(),'$..sku_id')
    yield sku_id
    # 后置，清除商品数据
    # 下架
    UnderGoodsApi(goods_ids=[goods_id]).send()
    # 删除--放到回收站
    RecycleGoodsApi(goods_ids=[goods_id]).send()
    # 彻底删除
    DeleteGoodsApi(goods_ids=[goods_id]).send()

@pytest.fixture(scope='class')
def address_data():
    resp = AddAddressApi().send()
    addr_id = resp.json()['addr_id']
    # 设置为订单的收货地址
    SetAddressIdApi(address_id=addr_id).send()
    yield
    # 清除地址
    DeleteAddressApi(id=addr_id)

