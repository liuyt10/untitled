# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : client.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-07-31 11:42
# @Copyright: 北京码同学
import requests

# 注意这个类是所有接口封装时的父类
from common.encry_decry import AesEncrypt
from common.logger import GetLogger


class RequestsClient:
    session = requests.session()#使用类属性来定一个session，他将作为所有接口发起的全局对象

    def __init__(self):
        self.session = RequestsClient.session
        self.logger = GetLogger.get_logger()
        self.url = None
        self.method = None
        self.headers = None
        self.params = None
        self.data = None
        self.json = None
        self.files = None
        self.resp = None
        # 假如你要做aes加解密
        # self.aes = AesEncrypt(key='0123456789123456')

    def send(self,**kwargs):
        # 如果调用方，没有传任何的参数，那么就使用该对象的默认属性参数
        if 'url' not in kwargs:
            kwargs['url'] = self.url
        if 'method' not in kwargs:
            kwargs['method'] = self.method
        if 'headers' not in kwargs:
            kwargs['headers'] = self.headers
        if 'params' not in kwargs:
            kwargs['params'] = self.params
        if 'data' not in kwargs:
            kwargs['data'] = self.data
        if 'json' not in kwargs:
            kwargs['json'] = self.json
        if 'files' not in kwargs:
            kwargs['files'] = self.files

        # 记录接口发起前的信息
        for key,value in kwargs.items():
            self.logger.info(f'接口的{key}是:{value}')
        # 发起之前针对所有的参数进行加密处理
        # data = self.aes.encrypt(kwargs)
        # kwargs['data'] = data
        try:
            self.resp = self.session.request(**kwargs)
            self.logger.info(f'接口响应状态码是:{self.resp.status_code}')
            self.logger.info(f'接口响应信息是:{self.resp.text}')
        except BaseException as e:
            self.logger.exception('接口发起报错')
            raise BaseException(f'接口发起报错:{e}')
        # 解密数据
        # data = self.aes.decrypt(self.resp.text)
        return self.resp
if __name__ == '__main__':
    # 登录接口
    r = RequestsClient()
    r.send(method='post',url='',data='')
