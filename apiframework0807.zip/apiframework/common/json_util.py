# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : json_util.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 14:40
# @Copyright: 北京码同学
import jsonpath
from jsonpath_rw import Index, Fields
from jsonpath_rw_ext import parse

from common.logger import GetLogger

logger = GetLogger.get_logger()
def extract_json(json_object,express,index=0):
    """
    json数据提取
    :param json_object: 目标对象
    :param express: jsonpath表达式
    :param index: 要提取的结果中的第几个，默认是第一个
    :return:
    """
    res = jsonpath.jsonpath(json_object, express)
    try:
        if res:
            if index<0:
                # 如果index小于0,则认为你是要所有的匹配结果
                return res
            else:
                # 如果不小于0，那么你传几，就代表你要的是匹配结果的某一个
                return res[index]
            logger.info(f'通过{express}提取到的结果是:{res}')
    except:
        logger.exception(f'通过{express}没有提取到值')




def update_value_to_json(json_object, json_path, new_value):
    json_path_expr = parse(json_path)
    # print(json_path_expr)
    for match in json_path_expr.find(json_object):
        # print(match)
        path = match.path
        print(path)
        if isinstance(path, Index):
            match.context.value[match.path.index] = new_value
        elif isinstance(path, Fields):
            match.context.value[match.path.fields[0]] = new_value
    return json_object


if __name__ == '__main__':
    s = { "store":
            {
            "book": [
              { "category": "reference",
                "author": "Nigel Rees",
                "title": "Sayings of the Century",
                "price": 8.95
              },
              { "category": "fiction",
                "author": "Evelyn Waugh",
                "title": "Sword of Honour",
                "price": 12.99
              },
              { "category": "fiction",
                "author": "Herman Melville",
                "title": "Moby Dick",
                "isbn": "0-553-21311-3",
                "price": 8.99
              },
              { "category": "fiction",
                "author": "J. R. R. Tolkien",
                "title": "The Lord of the Rings",
                "isbn": "0-395-19395-8",
                "price": 22.99
              }
            ],
            "bicycle": {
              "color": "red",
              "price": 19.95
            }
          }
        }
    # 注意：jsonpath一旦能匹配到数据，不管数据是几个，返回结果都是个列表
    # 注意：jsonpath一旦匹配不到数据，那么结果是False
    # res = jsonpath.jsonpath(s,'$..color1')
    res = extract_json(s,'$..title',3)
    print(res)

    # 修改s这个json里的第一个category
    s = update_value_to_json(s,'$..book[0].category','aaaaaaaaaa')
    print(s)
