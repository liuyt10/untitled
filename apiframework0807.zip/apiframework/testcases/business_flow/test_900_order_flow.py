# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : test_900_order_flow.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 10:24
# @Copyright: 北京码同学
import time

import allure
import javaobj
import pytest

from api.base_api import BaseBuyerApi
from api.buyer.cart_apis import BuyNowApi
from api.buyer.comment_apis import OrderCommentApi
from api.buyer.order_apis import CreateTradeApi, OrderRogApi
from api.seller.order_apis import DeliveryOrderApi, ConfirmPayOrderApi

@allure.feature('主流程测试')
@allure.story('订单流程测试')
@pytest.mark.usefixtures('address_data')
class TestOrderFlow:
    order_sn = ''
    pay_price = 0
    sku_id = ''

    # def setup_class(self):
    #     pass
    @allure.title('立即购买')
    def test_buy_now(self,redis_util,goods_data):
        TestOrderFlow.sku_id = goods_data
        buy_now_api = BuyNowApi(sku_id=TestOrderFlow.sku_id)
        resp = buy_now_api.send()
        assert resp.status_code == 200
        # redis数据校验
        res = redis_util.get(f'{{BUY_NOW_ORIGIN_DATA_PREFIX}}_{BaseBuyerApi.uid}')  # 59是用户id
        res_obejct = javaobj.loads(res)
        # 获取立即购买时存储到redis的num数量
        expect_num = res_obejct[0].__getattribute__('num')
        expect_skuid = res_obejct[0].__getattribute__('skuId')
        pytest.assume(expect_num == 1, f'实际值是:{expect_num},期望值是：1')
        pytest.assume(expect_skuid == TestOrderFlow.sku_id, f'实际值是:{expect_skuid},期望值是：{TestOrderFlow.sku_id}')
    # 创建交易
    @allure.title('创建交易')
    def test_create_trade(self,db_util):
        create_trade_api = CreateTradeApi()
        resp = create_trade_api.send()
        assert resp.status_code == 200
        # 数据库断言

        resp_sn = resp.json()['order_list'][0]['sn'] # 这就是订单编号
        TestOrderFlow.order_sn = resp_sn
        TestOrderFlow.pay_price = resp.json()['price_detail']['total_price']
        # db_util = DBUtil(host='121.42.15.146', user='root', password='Testfan#123')
        res = db_util.select(f'select * from mtxshop_trade.es_order where trade_sn={resp_sn}')
        # res是个列表套字典
        assert len(res) == 1
        time.sleep(1)
        pytest.assume(res[0]['order_status'] == 'CONFIRM',f'实际值是:{res[0]["order_status"]}')
    # 卖家发货
    @allure.title('卖家发货')
    def test_deliverty(self,db_util):
        # 需要订单编号作为入参，他从哪里来
        delivery_order_api=DeliveryOrderApi(order_sn=TestOrderFlow.order_sn)
        resp = delivery_order_api.send()
        assert resp.status_code == 200
        # 针对订单状态进行断言
        db_res = db_util.select(f'select order_status from mtxshop_trade.es_order where trade_sn={TestOrderFlow.order_sn}')
        assert len(db_res)==1
        db_order_status = db_res[0]['order_status']
        pytest.assume(db_order_status == 'SHIPPED',f'期望值SHIPPED，实际值是{db_order_status}')

    # 确认收货
    @allure.title('确认收货')
    def test_confirm_rog(self,db_util):
        order_rog_api = OrderRogApi(order_sn=TestOrderFlow.order_sn)
        resp = order_rog_api.send()
        assert resp.status_code == 200
        # 针对订单状态进行断言
        db_res = db_util.select(f'select order_status from mtxshop_trade.es_order where trade_sn={TestOrderFlow.order_sn}')
        assert len(db_res)==1
        db_order_status = db_res[0]['order_status']
        pytest.assume(db_order_status == 'ROG',f'期望值ROG，实际值是{db_order_status}')

    # 卖家确认收款
    @allure.title('卖家确认收款')
    def test_confirm_pay(self,db_util):
        confirm_pay_api = ConfirmPayOrderApi(order_sn=TestOrderFlow.order_sn,pay_price=TestOrderFlow.pay_price)
        resp  =confirm_pay_api.send()
        assert resp.status_code == 200
        # 针对订单状态进行断言
        db_res = db_util.select(f'select order_status from mtxshop_trade.es_order where trade_sn={TestOrderFlow.order_sn}')
        assert len(db_res)==1
        db_order_status = db_res[0]['order_status']
        pytest.assume(db_order_status == 'PAID_OFF',f'期望值PAID_OFF，实际值是{db_order_status}')

    # 买家评论
    @allure.title('买家评论')
    def test_comment(self):
        comment_api = OrderCommentApi(order_sn=TestOrderFlow.order_sn,sku_id=TestOrderFlow.sku_id)
        resp = comment_api.send()
        assert resp.status_code == 200

