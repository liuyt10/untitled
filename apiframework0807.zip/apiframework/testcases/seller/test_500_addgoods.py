# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : test_500_addgoods.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 14:57
# @Copyright: 北京码同学
import allure
import pytest

from api.seller.goods_apis import AddGoodsApi
from common.file_load import read_excel
from common.json_util import update_value_to_json

@allure.feature('卖家接口测试')
@allure.story('发布商品接口测试')
class TestAddGoodsApi:

    test_data = read_excel('/data/mtxshop_testdata.xlsx','添加商品数据')
    @pytest.mark.parametrize('casename,changeparams,expect_status',test_data)
    @allure.title('{casename}')
    def test_add_goods(self,casename,changeparams,expect_status):
        add_goods_api = AddGoodsApi()
        # 根据传递进来的changeparams，来修改接口的默认json数据
        changeparams = eval(changeparams) # 将json格式的字符串转成python里的字典
        """
        {
        "$.goods_name":"",
        "$.price":0
        }
        """
        for key,value in changeparams.items():
            # 这个key就是jsonpath表达式
            # 这个value就是目标字段的新值
            add_goods_api.json = update_value_to_json(add_goods_api.json,key,value)
            # 循环结束之后，接口的json数据就会被替换成新的
        # 发起接口调用
        resp = add_goods_api.send()
        assert resp.status_code == expect_status
