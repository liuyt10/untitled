# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : basic_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 10:07
# @Copyright: 北京码同学
from api.base_api import BaseBasicApi


class UploadsApi(BaseBasicApi):

    def __init__(self):
        super().__init__()
        self.url = f'{self.host}/uploaders'
        self.method = 'post'
        self.params = {
            'scene':'goods'
        }
        self.files = {
            # file对应的是一个元组
            # 元组的第一个是文件名称
            # 第二个是读取文件的二进制对象
            # 第三个是文件的类型
            'file':('logo.png',open(file=r'C:\Users\lixio\Desktop\logo.png',mode='rb'),'images/png')
        }