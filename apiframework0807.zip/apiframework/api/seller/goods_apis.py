# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : goods_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 9:45
# @Copyright: 北京码同学
from api.base_api import BaseSellerApi


class AddGoodsApi(BaseSellerApi):

    def __init__(self):
        super().__init__()
        self.url = f'{self.host}/seller/goods'
        self.method = 'post'
        self.json = {
            "brand_id": "",
            "category_id": 83,
            "category_name": "",
            "goods_name": "沙陌老师的炒锅",
            "sn": "sn0001",
            "price": "378",
            "mktprice": "388",
            "cost": "10",
            "weight": "1",
            "goods_gallery_list": [{
                "img_id": -1,
                "original": "http://www.mtxshop.com:7000/statics/attachment/goods/2022/8/7/9/43509990.png",
                "sort": 0
            }],
            "quantity": 99999999,
            "goods_transfee_charge": 1,
            "has_changed": 0,
            "market_enable": 1,
            "template_id": 0,
            "exchange": {
                "category_id": "",
                "enable_exchange": 0,
                "exchange_money": 0,
                "exchange_point": 0
            },
            "shop_cat_id": 0,
            "meta_description": "",
            "meta_keywords": "",
            "page_title": "",
            "goods_params_list": [],
            "sku_list": [],
            "intro": "<p>商品说明</p>"
        }

class ChangeGoodsApi(BaseSellerApi):

    def __init__(self,id):
        super().__init__()
        self.url = f'{self.host}/seller/goods/{id}'
        self.method = 'put'
        self.json = {
            "goods_id": id,
            "category_id": 83,
            "category_name": "厨房用品&gt;锅具水壶 &gt;炒锅",
            "shop_cat_id": 0,
            "brand_id": None,
            "goods_name": "沙陌老师的炒锅",
            "sn": "sn0002",
            "price": 378,
            "cost": 10,
            "mktprice": 388,
            "weight": 1,
            "goods_transfee_charge": 1,
            "intro": "<p>商品说明</p>",
            "have_spec": 0,
            "quantity": 99999999,
            "market_enable": 1,
            "goods_gallery_list": [{
                "img_id": 21860,
                "original": "http://www.mtxshop.com:7000/statics/attachment/goods/2022/8/7/9/43509990.png",
                "sort": None
            }],
            "page_title": "沙陌老师的炒锅",
            "meta_keywords": "沙陌老师的炒锅",
            "meta_description": "沙陌老师的炒锅",
            "template_id": 0,
            "is_auth": 0,
            "enable_quantity": 99999999,
            "auth_message": None,
            "goods_type": "NORMAL",
            "exchange": {
                "category_id": "",
                "enable_exchange": 0,
                "exchange_money": 0,
                "exchange_point": 0
            },
            "category_ids": [79, 80, 83],
            "promotion_tip": "",
            "sku_list": [],
            "has_changed": 0
        }

class GetSkuInfoGoodsApi(BaseSellerApi):

    def __init__(self,goods_id):
        super().__init__()
        self.url = f'{self.host}/seller/goods/{goods_id}/skus'
        self.method = 'get'


class UnderGoodsApi(BaseSellerApi):

    def __init__(self,goods_ids:list):
        super().__init__()
        # goods_ids = [1111,2222,3333]
        # 1
        # 要将传进来的goods_ids列表变成111,2222,333
        goods_ids = [str(x) for x in goods_ids] # ['1111','2222','3333']
        goods_ids = ','.join(goods_ids) # 111,2222,333
        self.url = f'{self.host}/seller/goods/{goods_ids}/under'
        self.method = 'put'
class RecycleGoodsApi(BaseSellerApi):

    def __init__(self,goods_ids:list):
        super().__init__()
        # goods_ids = [1111,2222,3333]
        # 1
        # 要将传进来的goods_ids列表变成111,2222,333
        goods_ids = [str(x) for x in goods_ids] # ['1111','2222','3333']
        goods_ids = ','.join(goods_ids) # 111,2222,333
        self.url = f'{self.host}/seller/goods/{goods_ids}/recycle'
        self.method = 'put'
class DeleteGoodsApi(BaseSellerApi):

    def __init__(self,goods_ids:list):
        super().__init__()
        # goods_ids = [1111,2222,3333]
        # 1
        # 要将传进来的goods_ids列表变成111,2222,333
        goods_ids = [str(x) for x in goods_ids] # ['1111','2222','3333']
        goods_ids = ','.join(goods_ids) # 111,2222,333
        self.url = f'{self.host}/seller/goods/{goods_ids}'
        self.method = 'delete'
