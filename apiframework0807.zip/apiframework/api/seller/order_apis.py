# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : order_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 9:52
# @Copyright: 北京码同学
from api.base_api import BaseSellerApi


class DeliveryOrderApi(BaseSellerApi):

    def __init__(self,order_sn):
        super().__init__()
        self.url = f'{self.host}/seller/trade/orders/{order_sn}/delivery'
        self.method = 'post'
        self.data = {
            'ship_no':'hhhdhjxxx11',
            'logi_id':12,
            'logi_name':'中通'
        }
class ConfirmPayOrderApi(BaseSellerApi):

    def __init__(self,order_sn,pay_price):
        super().__init__()
        self.url = f'{self.host}/seller/trade/orders/{order_sn}/pay'
        self.method = 'post'
        self.data = {
            'pay_price':pay_price
        }