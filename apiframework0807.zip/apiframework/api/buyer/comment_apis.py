# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : comment_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 9:36
# @Copyright: 北京码同学
from api.base_api import BaseBuyerApi


class OrderCommentApi(BaseBuyerApi):

    def __init__(self,order_sn,sku_id,content='非常满意的一次购物体验'):
        super().__init__()
        self.url = f'{self.host}/members/comments'
        self.method = 'post'
        self.json = {
          "comments": [
            {
              "content": content,
              "grade": "good",
              "images": [],
              "sku_id": sku_id
            }
          ],
          "delivery_score": 5,
          "description_score": 5,
          "order_sn": order_sn,
          "service_score": 5
        }