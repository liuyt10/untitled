# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : member_address_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 13:59
# @Copyright: 北京码同学
from api.base_api import BaseBuyerApi


class AddAddressApi(BaseBuyerApi):

    def __init__(self):
        super().__init__()
        self.url = f'{self.host}/members/address'
        self.method = 'post'
        self.data = {
            "name":"沙陌",
            "addr": "这是详细地址",
            "mobile": "18729399607",
            "def_addr": 0,
            "ship_address_name": "这是地址别名",
            "region": 2799,
        }

class DeleteAddressApi(BaseBuyerApi):

    def __init__(self,id):
        super().__init__()
        self.url = f'{self.host}/members/address/{id}'
        self.method = 'delete'