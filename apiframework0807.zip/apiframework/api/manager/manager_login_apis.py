# !/usr/bin python3                                 
# encoding: utf-8 -*-   
# @file     : manager_login_apis.py                       
# @author   : 沙陌 Matongxue_2
# @Time     : 2022-08-07 9:59
# @Copyright: 北京码同学
from api.base_api import BaseManagerApi
from common.encry_decry import md5


class ManagerLoginApi(BaseManagerApi):

    def __init__(self, username, password):
        super().__init__()
        self.url = f'{self.host}/admin/systems/admin-users/login'
        self.method = 'get'
        self.params = {
            'username': username,
            'password': md5(password),
            'captcha': '1512',
            'uuid': 'sdhhjshjdhdhd'
        }